package com.example.autoclicker

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val startBtn = findViewById<Button>(R.id.startButton)
        val stopBtn = findViewById<Button>(R.id.stopButton)

        startBtn.setOnClickListener {
            startService(Intent(this, AutoClickService::class.java))
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        stopBtn.setOnClickListener {
            stopService(Intent(this, AutoClickService::class.java))
        }
    }
}